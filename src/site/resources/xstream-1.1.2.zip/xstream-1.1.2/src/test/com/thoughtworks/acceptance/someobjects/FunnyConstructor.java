package com.thoughtworks.acceptance.someobjects;

import com.thoughtworks.acceptance.StandardObject;

public class FunnyConstructor extends StandardObject {
    public int i;

    public FunnyConstructor(int i) {
        this.i = i;
    }

}
